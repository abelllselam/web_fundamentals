
function bye (element){
    var disappear = document.querySelector('.btn-bottom');
    disappear.remove();
}

function change () {
    var makeChange = document.querySelector('.btn-nav');
    makeChange.innerText = "Logout";
}